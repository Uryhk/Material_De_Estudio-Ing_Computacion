El sistema de observabilidad registra estaciones críticas en un árbol AVL ordenado por EstacionCritica.id. Para auditar el estado del balanceo, se necesita calcular el factor de balance de una estación específica.

El factor de balance se define como:

altura(subárbol izquierdo) - altura(subárbol derecho)
En este ejercicio, la altura de un árbol vacío es 0 y la altura de una hoja es 1.

Implemente exactamente estos métodos:

int MonitorAVL::alturaDe(NodoAVL* nodo);
int MonitorAVL::factorBalanceDe(int estacionId);
factorBalanceDe debe devolver 999 si la estación no existe.
![alt text](image-7.png)

Código base visible para el estudiante:

```cpp
struct EstacionCritica {
    int id;
    std::string nombre;

    EstacionCritica(int idEstacion = -1,
                    std::string nombreEstacion = "");
};

class NodoAVL {
public:
    EstacionCritica dato;
    NodoAVL* izquierdo;
    NodoAVL* derecho;

    explicit NodoAVL(EstacionCritica estacion);
};

class MonitorAVL {
private:
    NodoAVL* raiz;

public:
    MonitorAVL();
    void insertarParaTest(EstacionCritica estacion);

    // Métodos a implementar.
    int alturaDe(NodoAVL* nodo);
    int factorBalanceDe(int estacionId);
};```

Restricciones:

Use recursión para calcular altura.
Use la propiedad de búsqueda por id para encontrar la estación.
No use estructuras auxiliares.

```cpp
    int MonitorAVL::alturaDe(NodoAVL* nodo) {
    if (nodo == nullptr)
    {
        return 0;
    }

    int alturaIzq = alturaDe(nodo->izquierdo);
    int alturaDer = alturaDe(nodo->derecho);

    int mayorAltura = (alturaIzq >= alturaDer) ? alturaIzq : alturaDer;

    return 1 + mayorAltura; 
}

int MonitorAVL::factorBalanceDe(int estacionId) {
    return 0; // Reemplazar por tu implementacion
}








/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.


int MonitorAVL::factorBalanceDe(int estacionId) {
    auto actual = raiz;

    while (actual != nullptr)
    {
        if (actual->dato.id == estacionId)
        {
            return alturaDe(actual->izquierdo) - alturaDe(actual->derecho);
        }

        if (actual->dato.id > estacionId)
        {
            actual = actual->izquierdo;
        }
        else
        {
            actual = actual->derecho;
        }
    }

    return 999;  
}
*/

```