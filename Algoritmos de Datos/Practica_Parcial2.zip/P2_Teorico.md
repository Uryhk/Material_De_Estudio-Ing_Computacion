![Teorico1](image-4.png) b
![Teorico2](image-5.png) a
![Teorico3](image-9.png) a, b
![Teorico4](image-13.png) d, c