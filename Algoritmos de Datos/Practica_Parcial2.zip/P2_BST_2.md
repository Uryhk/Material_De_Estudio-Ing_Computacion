Durante la madrugada, el Centro de Control Ferroviario recibe solicitudes de despacho desde distintos nodos de la ciudad. Cada solicitud incluye el código operativo de un tren. Antes de autorizar una maniobra, el sistema debe consultar si ese tren está registrado y cuál es su prioridad operativa.

Para evitar recorrer todo el registro linealmente, Exodus Systems mantiene los trenes cargados en un Árbol Binario de Búsqueda ordenado por Tren.codigo.

Implemente exactamente este método:

ResultadoBusqueda RegistroTrenes::buscarPorCodigo(int codigoBuscado)
El método debe devolver:

ResultadoBusqueda(true, tren) si existe un tren con ese código.
ResultadoBusqueda(false, Tren()) si no existe.
Código base visible para el estudiante:

![alt text](image-10.png)

```cpp
struct Tren {
    int codigo;
    std::string linea;
    int prioridadOperativa;

    Tren(int codigoTren = -1,
         std::string lineaTren = "",
         int prioridad = 0);
};

struct ResultadoBusqueda {
    bool encontrado;
    Tren tren;

    ResultadoBusqueda(bool fueEncontrado = false,
                      Tren trenEncontrado = Tren());
};

class NodoTren {
public:
    Tren dato;
    NodoTren* izquierdo;
    NodoTren* derecho;

    explicit NodoTren(Tren tren);
};

class RegistroTrenes {
private:
    NodoTren* raiz;

public:
    RegistroTrenes();
    void insertar(Tren tren);

    // Método a implementar.
    ResultadoBusqueda buscarPorCodigo(int codigoBuscado);
};
```

Restricciones:

Use la propiedad del BST: menor a la izquierda, mayor a la derecha.
No recorra ambos subárboles si el orden permite descartar uno.
No use arreglos, vectores, listas auxiliares ni estructuras STL.
No modifique el árbol.

```cpp
ResultadoBusqueda RegistroTrenes::buscarPorCodigo(int codigoBuscado) {
    return ResultadoBusqueda(false, Tren()); // Reemplazar por tu implementacion
}





/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.





ResultadoBusqueda RegistroTrenes::buscarPorCodigo(int codigoBuscado) {
    auto actual = raiz;
    
    while (actual != nullptr)
    {
        if (actual->dato.codigo == codigoBuscado)
        {
            return ResultadoBusqueda(true, actual->dato);
        }
        if (actual->dato.codigo > codigoBuscado)
        {
            actual = actual->izquierdo;
        }
        if (actual->dato.codigo < codigoBuscado)
        {
            actual = actual->derecho;   
        }
    }
    
    return ResultadoBusqueda(false, Tren());
}
*/
```