Una brigada debe llegar a una estación dañada atravesando únicamente estaciones habilitadas. El sistema no necesita saber la cantidad de transbordos, solo si existe al menos una ruta segura.

La red se modela como un grafo no ponderado. Una ruta es segura si todas las estaciones del camino están habilitadas.

Implemente exactamente este método:

bool RedSegura::existeRutaSegura(int origenId, int destinoId)
Debe devolver:

false si algún id es inválido.
false si origen o destino no están habilitados.
false si no existe ruta segura.
true si origen y destino son la misma estación habilitada.
true si existe al menos una ruta segura.
Contrato completo de la cola provista:

```cpp
template <typename TData>
class Queue {
public:
    Queue();

    // Agrega value al final de la cola.
    void enqueue(const TData& value);

    // Elimina el elemento del frente. Si la cola está vacía, no hace nada.
    void dequeue();

    // Devuelve una COPIA del elemento del frente.
    // Solo debe llamarse si isEmpty() == false.
    TData front() const;

    // Devuelve true si la cola no tiene elementos.
    bool isEmpty() const;

    // Devuelve la cantidad de elementos actuales.
    int size() const;
};

//Código base visible para el estudiante:

struct EstacionSegura {
    std::string nombre;
    bool habilitada;

    EstacionSegura(std::string nombreEstacion = "",
                   bool estaHabilitada = true);
};

class RedSegura {
private:
    static const int MAX_ESTACIONES = 20;

    EstacionSegura estaciones[MAX_ESTACIONES];
    bool hayTunel[MAX_ESTACIONES][MAX_ESTACIONES];
    int cantidadEstaciones;

public:
    RedSegura();

    int agregarEstacion(std::string nombre,
                        bool habilitada = true);

    void conectarBidireccional(int origenId,
                               int destinoId);

    // Método a implementar.
    bool existeRutaSegura(int origenId,
                          int destinoId);
};
```
Restricciones:

Use BFS con Queue<int>, donde cada int representa el id de una estación pendiente de explorar.
No use std::queue.
No use vector.
No use recursión.

![alt text](image-1.png)

```cpp
bool RedSegura::existeRutaSegura(int origenId, int destinoId) {
    return false;  // Reemplazar por tu implementacion
}




/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.
bool RedSegura::existeRutaSegura(int origenId, int destinoId) {
    if (origenId < 0 || 
        destinoId < 0 || 
        origenId >= cantidadEstaciones || 
        destinoId >= cantidadEstaciones) 
        {
            return false;   // Verifico si los Id son validos
        }

    if (!(estaciones[origenId].habilitada && estaciones[destinoId].habilitada)) 
        {
            return false;   // Verifico que origen y destino esten habilitadas
        }

    if (origenId == destinoId)
        {
            return true;    // Verifico si origen y destino son la misma estacion habilitada
        }

    int n = cantidadEstaciones;

    bool visitada[MAX_ESTACIONES] = {false};
    Queue<int> cola;

    visitada[origenId] = true;
    cola.enqueue(origenId);

    while(!cola.isEmpty())
        {
            int actual = cola.front();
            cola.dequeue();

            if (actual == destinoId)
                {
                    return true;
                }

            for (int i = 0; i < n; i++)
                {
                    if (hayTunel[actual][i] && estaciones[i].habilitada && !visitada[i])
                    {
                        visitada[i] = true;
                        cola.enqueue(i);
                    }
                }
        }

    return false;
}
*/

```