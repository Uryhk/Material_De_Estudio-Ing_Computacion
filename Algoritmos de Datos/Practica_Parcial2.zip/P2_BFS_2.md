Una tormenta electromagnética dejó fuera de servicio algunas estaciones del sistema nocturno. El centro de control debe decidir cuántos transbordos mínimos necesita un equipo técnico para viajar desde una estación origen hasta una estación destino usando solamente estaciones operativas.

La red se modela como un grafo no ponderado:

Cada estación es un nodo.
Cada túnel bidireccional es una arista.
Cada túnel cuesta exactamente 1 transbordo.
Como todas las aristas tienen el mismo costo, la estrategia correcta es explorar por niveles usando BFS.

Implemente exactamente este método:

int RedTrenes::minimoTransbordosSeguros(int origenId, int destinoId)
Debe devolver:

-1 si algún id es inválido.
-1 si origen o destino no están operativos.
-1 si no existe ruta segura.
0 si origen y destino son la misma estación operativa.
La mínima cantidad de transbordos en cualquier otro caso.
Contrato completo de la cola provista:

![alt text](image-11.png)

```cpp
template <typename TData>
class Queue {
public:
    Queue();

    // Agrega value al final de la cola.
    void enqueue(const TData& value);

    // Elimina el elemento del frente. Si la cola está vacía, no hace nada.
    void dequeue();

    // Devuelve una COPIA del elemento del frente.
    // Solo debe llamarse si isEmpty() == false.
    TData front() const;

    // Devuelve true si la cola no tiene elementos.
    bool isEmpty() const;

    // Devuelve la cantidad de elementos actuales.
    int size() const;
};
```

Código base visible para el estudiante:

```cpp
struct Estacion {
    std::string nombre;
    bool operativa;

    Estacion(std::string nombreEstacion = "",
             bool estaOperativa = true);
};

struct EstadoBusqueda {
    int estacionId;
    int distancia;

    EstadoBusqueda(int id = -1, int dist = 0);
};

class RedTrenes {
private:
    static const int MAX_ESTACIONES = 20;

    Estacion estaciones[MAX_ESTACIONES];
    bool hayTunel[MAX_ESTACIONES][MAX_ESTACIONES];
    int cantidadEstaciones;

public:
    RedTrenes();

    int agregarEstacion(std::string nombre,
                        bool operativa = true);

    void cambiarEstadoOperativo(int estacionId,
                                bool operativa);

    void conectarBidireccional(int origenId,
                               int destinoId);

    // Método a implementar.
    int minimoTransbordosSeguros(int origenId,
                                 int destinoId);
};
```

Restricciones:

Use Queue<EstadoBusqueda>.
No use std::queue.
No use vector.
No use recursión.

```cpp
int RedTrenes::minimoTransbordosSeguros(int origenId, int destinoId) {
    return 0; // Reemplazar por tu implementacion
}






/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.





int RedTrenes::minimoTransbordosSeguros(int origenId, int destinoId) {
    if (origenId  < 0 ||
        destinoId < 0 ||
        origenId  >= cantidadEstaciones ||
        destinoId >= cantidadEstaciones)
        {
            return -1;
        }
    if (!estaciones[origenId].operativa ||
        !estaciones[destinoId].operativa)
        {
            return -1;
        }
    if (origenId == destinoId)
    {
        return 0;
    }
    
    //EstadoBusqueda estado(origenId, 0);
    int n = cantidadEstaciones;
    bool visitada[MAX_ESTACIONES] = { false };
    Queue<EstadoBusqueda> cola;
    int contador = 0;
    
    visitada[origenId] = true;
    cola.enqueue(EstadoBusqueda(origenId));
    
    while (!cola.isEmpty())
    {
        int actual = cola.front().estacionId;
        
        if (actual == destinoId)
        {
            return cola.front().distancia;
        }
        cola.dequeue();
        
        for (int i = 0; i < n; i++)
        {
            if (hayTunel[actual][i] &&
                estaciones[i].operativa &&
                !visitada[i])
            {
                visitada[i] = true;
                contador++;
                cola.enqueue(EstadoBusqueda(i, contador));
            }
        }
    }
    
    return -1;
    
}
*/
```