Durante la madrugada, algunos túneles consumen distinta cantidad de energía por interferencias electromagnéticas. Antes de enviar un tren de mantenimiento, el centro de control debe calcular el costo energético mínimo entre dos estaciones.

La red se modela como un grafo ponderado:

Cada estación es un nodo.
Cada túnel bidireccional tiene un costo energético positivo.
El costo de una ruta es la suma de los costos de sus túneles.
Como todos los costos son positivos, la estrategia correcta es Dijkstra.

Implemente exactamente este método:

int MetroNocturno::costoMinimoEnergia(int origenId, int destinoId)
Debe devolver:

-1 si algún id es inválido.
-1 si no existe ruta.
0 si origen y destino coinciden.
El costo energético mínimo en cualquier otro caso.
![alt text](image-8.png)

Código base visible para el estudiante:

```cpp
struct Tunel {
    bool existe;
    int costoEnergia;

    Tunel(bool existeTunel = false,
          int costo = 0);
};

class MetroNocturno {
private:
    static const int MAX_ESTACIONES = 20;
    static const int COSTO_INFINITO = 999999;

    std::string nombres[MAX_ESTACIONES];
    Tunel conexiones[MAX_ESTACIONES][MAX_ESTACIONES];
    int cantidadEstaciones;

public:
    MetroNocturno();

    int agregarEstacion(std::string nombre);

    void conectarBidireccional(int origenId,
                               int destinoId,
                               int costoEnergia);

    // Método a implementar.
    int costoMinimoEnergia(int origenId,
                           int destinoId);
};```

Restricciones:

No use priority_queue.
No use vector.
Implemente Dijkstra con arreglos locales.
No use INT_MAX; use COSTO_INFINITO, que está definido en la clase.

```cpp

int MetroNocturno::costoMinimoEnergia(int origenId, int destinoId) {
    return 0; // Reemplazar por tu implementacion
}




/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.





    int MetroNocturno::costoMinimoEnergia(int origenId, int destinoId) {
    if (origenId  < 0 ||
        destinoId < 0 ||
        origenId  >= cantidadEstaciones ||
        destinoId >= cantidadEstaciones)
    {
        return -1;
    }

    if (origenId == destinoId)
    {
        return 0;
    }

    int n = cantidadEstaciones;
    bool visitada[MAX_ESTACIONES] = { false };
    int costo[MAX_ESTACIONES];

    for (int i = 0; i < MAX_ESTACIONES; i++)
    {
        costo[i] = COSTO_INFINITO;
    }

    costo[origenId] = 0;

    for (int paso = 0; paso < n; paso++)
    {
        int actual = -1;
        int menorCosto = COSTO_INFINITO;

        for (int i = 0; i < n; i++)
        {
            if (!visitada[i] && (costo[i] < menorCosto))
            {
                actual = i;
                menorCosto = costo[i];
            }
        }

        if (actual == -1) { break; }

        visitada[actual] = true;

        for (int vecino = 0; vecino < n; vecino++)
        {
            if (conexiones[actual][vecino].existe && !visitada[vecino])
            {
                int costoActual = conexiones[actual][vecino].costoEnergia + costo[actual];

                if (costoActual < costo[vecino])
                {
                    costo[vecino] = costoActual;
                }   
            }
        }
    }

    if (costo[destinoId] == COSTO_INFINITO) { return -1; }

    return costo[destinoId];

}
*/

```