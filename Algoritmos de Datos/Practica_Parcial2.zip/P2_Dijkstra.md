Los túneles del sistema nocturno tienen un nivel de riesgo operativo según interferencia, seguridad y estado estructural. El centro de control necesita seleccionar la ruta de menor riesgo acumulado para mover una brigada.

La red se modela como un grafo ponderado:

Cada estación es un nodo.
Cada tramo bidireccional tiene un riesgo positivo.
El riesgo de una ruta es la suma de los riesgos de sus tramos.
Como todos los riesgos son positivos, se debe usar Dijkstra.

Implemente exactamente este método:

int RedRiesgo::riesgoMinimo(int origenId, int destinoId)
Debe devolver:

-1 si algún id es inválido.
-1 si no hay ruta.
0 si origen y destino coinciden.
El menor riesgo acumulado en cualquier otro caso.

![alt text](image-2.png)

Código base visible para el estudiante:

```cpp
struct TramoRiesgo {
    bool existe;
    int riesgo;

    TramoRiesgo(bool existeTramo = false,
                int riesgoTramo = 0);
};

class RedRiesgo {
private:
    static const int MAX_ESTACIONES = 20;
    static const int RIESGO_INFINITO = 999999;

    std::string nombres[MAX_ESTACIONES];
    TramoRiesgo tramos[MAX_ESTACIONES][MAX_ESTACIONES];
    int cantidadEstaciones;

public:
    RedRiesgo();

    int agregarEstacion(std::string nombre);

    void conectarBidireccional(int origenId,
                               int destinoId,
                               int riesgo);

    // Método a implementar.
    int riesgoMinimo(int origenId,
                     int destinoId);
};
```

Restricciones:

No use priority_queue.
No use vector.
Implemente Dijkstra con arreglos locales.
No use INT_MAX; use RIESGO_INFINITO, que está definido en la clase.

```cpp

int RedRiesgo::riesgoMinimo(int origenId, int destinoId) {
    return 0; // Reemplazar por tu implementacion
}





/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.





int RedRiesgo::riesgoMinimo(int origenId, int destinoId) {
    if (origenId  < 0 ||
        destinoId < 0 ||
        origenId  >= cantidadEstaciones ||
        destinoId >= cantidadEstaciones)
    {
        return -1;
    }

    if (origenId == destinoId)
    {
        return 0;
    }

    int n = cantidadEstaciones;

    int distancia[MAX_ESTACIONES];
    bool visitada[MAX_ESTACIONES] = {false};

    for (int i = 0; i < n; i++)
    {
        distancia[i] = RIESGO_INFINITO;
    }

    distancia[origenId] = 0;

    for (int paso = 0; paso < n; paso++)     
    {
        int actual = -1;
        int menorDistancia = RIESGO_INFINITO;
        for (int j = 0; j < n; j++) // Debo elegir desde que nodo voy a empezar a buscar vecinos
        {
            if (!visitada[j] && (distancia[j] < menorDistancia))
            {
                actual = j;
                menorDistancia = distancia[j];
            }
            
        }

        if (actual == -1) { break; }

        visitada[actual] = true;

        for (int vecino = 0; vecino < n; vecino++) // Mido distancia a los n vecinos desde el nod elegido
        {
            if (tramos[actual][vecino].existe && !visitada[vecino])
            {
                int distanciaNueva = distancia[actual] + tramos[actual][vecino].riesgo;

                if (distanciaNueva < distancia[vecino])
                {
                    distancia[vecino] = distanciaNueva;
                }
            }
        }
        
    }

    if (distancia[destinoId] == RIESGO_INFINITO) { return -1;}

    return distancia[destinoId];
    
}
*/

```