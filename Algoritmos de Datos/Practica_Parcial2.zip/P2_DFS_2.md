Luego de un sabotaje sobre la red de túneles, el equipo de monitoreo necesita saber cuántas estaciones operativas siguen conectadas al sector donde se encuentra una cuadrilla técnica.

La red se modela como un grafo no ponderado. Desde una estación origen se debe recorrer en profundidad y contar solo estaciones operativas alcanzables.

Implemente exactamente estos métodos:

int RedDiagnostico::contarDFS(int estacionId, bool visitada[]);
int RedDiagnostico::contarEstacionesOperativasDesde(int origenId);
contarEstacionesOperativasDesde debe devolver 0 si el id es inválido o si la estación origen no está operativa.

Código base visible para el estudiante:

![alt text](image-12.png)

```cpp
struct Estacion {
    std::string nombre;
    bool operativa;

    Estacion(std::string nombreEstacion = "",
             bool estaOperativa = true);
};

class RedDiagnostico {
private:
    static const int MAX_ESTACIONES = 20;

    Estacion estaciones[MAX_ESTACIONES];
    bool hayTunel[MAX_ESTACIONES][MAX_ESTACIONES];
    int cantidadEstaciones;

    // Helper recursivo a implementar.
    int contarDFS(int estacionId, bool visitada[]);

public:
    RedDiagnostico();

    int agregarEstacion(std::string nombre,
                        bool operativa = true);

    void conectarBidireccional(int origenId,
                               int destinoId);

    // Método público a implementar.
    int contarEstacionesOperativasDesde(int origenId);
};
```
Restricciones:

Use DFS recursivo.
No use queue, stack, vector ni estructuras auxiliares dinámicas.
Use el arreglo visitada provisto para evitar ciclos.

```cpp
int RedDiagnostico::contarDFS(int estacionId, bool visitada[]) {
    return 0; // Reemplazar por tu implementacion
}

int RedDiagnostico::contarEstacionesOperativasDesde(int origenId) {
    return 0; // Reemplazar por tu implementacion
}




/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.





int RedDiagnostico::contarDFS(int estacionId, bool visitada[]) {
    int n = cantidadEstaciones;
    int contador = 1;
    
    int actual = estacionId;
    visitada[actual] = true;
    
    for (int vecino = 0; vecino < n; vecino++)
    {
        if(hayTunel[actual][vecino] &&
           estaciones[vecino].operativa &&
           !visitada[vecino])
           {
               contador += contarDFS(vecino, visitada);
           }
    }
    
    return contador;
}

int RedDiagnostico::contarEstacionesOperativasDesde(int origenId) {
    if (origenId < 0 || origenId >= cantidadEstaciones)
    {
        return 0;
    }
    if (!estaciones[origenId].operativa) 
    { 
        return 0;
    }
    
    bool visitada[MAX_ESTACIONES] = { false };
    
    return contarDFS(origenId, visitada);
    
}
*/
```