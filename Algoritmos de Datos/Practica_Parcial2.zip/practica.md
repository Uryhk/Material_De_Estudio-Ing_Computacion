ALGORITMOS GENERICOS

```cpp
int dijkstra(int origen, int destino) {

    if (origen  < 0 ||
        destino < 0 ||
        origen  >= cantidad ||
        destino >= cantinad)
    {
        return -1;
    }

    if (origen == destino)
    {
        return 0;
    }

    int n = cantidad;

    int costo[MAX_SIZE];
    bool visitado[MAX_SIZE] = { false };

    for (int i = 0; i < n; i++)
    {
        costo[i] = INF;
    }

    costo[0] = 0;

    for (int paso = 0; paso < n; paso++)
    {
        int actual = -1;
        int menorCosto = INF;

        for (int j = 0; j < n; j++)
        {
            if (!visitado[j] && costo[j] < menorCosto)
            {
                actual = j;
                menorCosto = costo[j];
            }
        }
        if (actual == -1) { break; }

        visitado[actual] = true;

        for (int vecino = 0; vecino < n; vecino++)
        {
            if (tramo[actual][vecino].existe && !visitado[vecino])
            {
                int costoActual = costo[actual] + tramo[actual][vecino].costo;

                if (costoActual < costo[vecino])
                {
                    costo[vecino] = costoActual;
                }
            }
        }
    }

    if (costo[destino] == INF) { return -1; }

    return costo[destino];
}

------------------------------------------------------------------------------------
DFS
int dfsComponente(int origen, visitado[]){
    
    int n = cantidad;
    int actual = origen;
    int contador = 1;

    visitado[actual] = true;

    for (int vecino = 0; vecino < n; vecino++)
    {
        if (tramo[actual][vecino] &&
            nodo[vecino].operativo &&
            !visitado[vecino])
            {   
                contador += dfsComponente(vecino, visitado);
            }
    }

    return contador;
}

int tamanioComponenteOperativa(int origen){
    if (origen < 0 || origen >= cantidad || !nodo[origen].operativo)
    {
        return 0;
    }

    bool visitado[MAX] = { false };

    return dfsComponente(origen, visitado);
}

-------------------------------------------------------------------------------------
BFS
bool existeRutaOperativa(int origen, int destino) {
    
    if (origen  < 0 ||
        destino < 0 ||
        origen  >= cantidad ||
        destino >= cantidad)
    {
        return false;
    }

    if (!nodo[origen].operativo || !nodo[destino].operativo)
    {
        return false;
    }

    if (origen == destino)
    {
        return true;
    }

    int n = cantidad;
    bool visitado[MAX] = { false };
    Queue<int> cola;

    visitado[origen] = true;
    cola.push(origen);

    while (!cola.empty())
    {
        int actual = cola.front();
        cola.pop();

        if (actual == destino) { return true; }

        for (int vecino = 0; vecino < n; vecino++)
        {
            if (tramo[actual][vecino] &&
                nodo[vecino].operativo &&
                !visitado[vecino])
            {
                visitado[vecino] = true;
                cola.push(vecino);
            }
        }
    }

    return false;
}

------------------------------------------------------------------------------------
AVL
int altura(Nodo* nodo){
    if (nodo == nullptr)
    {
        return 0;
    }

    int alturaIzq = altura(nodo->izquierda);
    int alturaDer = altura(nodo->derecha);
    
    int mayorAltura = (alturaIzq >= alturaDer) ? alturaIzq : alturaDer;

    return 1 + mayorAltura;

}

int factorBalance(int id){
    auto actual = raiz;

    while (actual != nullptr)
    {
        if (actual->dato.id == id)
        {
            return altura(actual->izquierdo) - altura(actual->derecho);
        }

        if (actual->dato.id < id)
        {
            actual = actual->derecho;
        }

        if (actual->dato.id > id)
        {
            actual = actual->izquierdo;
        }
    }
    
    return 999;
}

------------------------------------------------------------------------------------
BST
int contarEnTramo(Nodo* nodo, int minimo, int maximo){
    if (nodo == nullptr) { return 0; }
    
    if (nodo->dato.valor < minimo)
    {
        return contarEnTramo(nodo->derecho, minimo, maximo);
    }

    if (nodo->dato.valor > maximo)
    {
        return contarEnTramo(nodo->izquierda, minimo, maximo);
    }

    return 1 + contarEnTramo(nodo->izquierda, minimo, maximo)
             + contarEnTramo(nodo->derecho, minimo, maximo);
}

int cantidadEnTramo(int minimo, int maximo){
    if (minimo > maximo)
    {
        return 0;
    }

    return contarEnTramo(raiz, minimo, maximo);
}
```