El despacho nocturno guarda servicios programados en un BST ordenado por ServicioTren.minutoSalida. Para estimar carga operativa, se necesita contar cuántos servicios salen dentro de una ventana horaria.

Implemente exactamente estos métodos:

int AgendaServicios::contarEnVentanaRec(NodoServicio* actual,
                                        int minutoDesde,
                                        int minutoHasta);

int AgendaServicios::cantidadServiciosEnVentana(int minutoDesde,
                                                int minutoHasta);
La ventana es inclusiva: un servicio cuenta si:

minutoDesde <= minutoSalida <= minutoHasta
Si la ventana es inválida (minutoDesde > minutoHasta), debe devolver 0.
![alt text](image-6.png)

Código base visible para el estudiante:

```cpp
struct ServicioTren {
    int codigoTren;
    int minutoSalida;
    std::string anden;

    ServicioTren(int codigo = -1,
                 int minuto = 0,
                 std::string nombreAnden = "");
};

class NodoServicio {
public:
    ServicioTren dato;
    NodoServicio* izquierdo;
    NodoServicio* derecho;

    explicit NodoServicio(ServicioTren servicio);
};

class AgendaServicios {
private:
    NodoServicio* raiz;

    // Helper recursivo a implementar.
    int contarEnVentanaRec(NodoServicio* actual,
                           int minutoDesde,
                           int minutoHasta);

public:
    AgendaServicios();
    void insertar(ServicioTren servicio);

    // Método público a implementar.
    int cantidadServiciosEnVentana(int minutoDesde,
                                   int minutoHasta);
};```

Restricciones:

Use recursividad.
Use la propiedad del BST para podar ramas que no pueden aportar resultados.
No use vector, arreglos auxiliares ni estructuras STL.

```cpp

int AgendaServicios::contarEnVentanaRec(NodoServicio* actual,
                                           int minutoDesde,
                                           int minutoHasta) {
    return 0; // Reemplazar por tu implementacion                                                    
}





/*   --------- SOLUCION --------- Primero, intenta resolverlo solo.


int AgendaServicios::contarEnVentanaRec(NodoServicio* actual,
                                           int minutoDesde,
                                           int minutoHasta) {
    if (actual == nullptr) { return 0; }

    if (actual->dato.minutoSalida < minutoDesde)
    {
        return contarEnVentanaRec(actual->derecho, minutoDesde, minutoHasta);
    }

    if (actual->dato.minutoSalida > minutoHasta)
    {
        return contarEnVentanaRec(actual->izquierdo, minutoDesde, minutoHasta);
    }

    return 1 + contarEnVentanaRec(actual->izquierdo, minutoDesde, minutoHasta)
             + contarEnVentanaRec(actual->derecho, minutoDesde, minutoHasta);
}

int AgendaServicios::cantidadServiciosEnVentana(int minutoDesde,
                                                int minutoHasta) {
    if (minutoDesde > minutoHasta)
    {
        return 0;
    }

    return contarEnVentanaRec(raiz, minutoDesde, minutoHasta);
}
*/

```